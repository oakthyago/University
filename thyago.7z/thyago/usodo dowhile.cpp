#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <math.h>


int main ()
 {   
    int n,s=0,k=0,t,x,y=0 ;
    
    
    do { 
         scanf ("%d",&n);
         
         
         y++;
         }while (n>=10);
         
         for (t=1;k;k++)
         { s=s+n;
         x=s/y;
         
         
}        
         printf ("A media foi %0.2%d", x);
         system("pause");
         
         }
         
          
